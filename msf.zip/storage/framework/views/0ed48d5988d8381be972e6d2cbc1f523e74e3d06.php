<?php $__env->startComponent('mail::message'); ?>
# Hello,

Some info here
<br>
<br>
<br>

<b>Email: </b> <?php echo e($anonymous->email); ?><br>
<hr>
<b>Ethereum address: </b> <?php echo e($anonymous->ethereum_address); ?><br>
<hr>
<b>Privacy: </b> <?php echo e($anonymous->privacy); ?><br>
<hr>
<b>Type: </b> <?php echo e($anonymous->type); ?><br>
<hr>
<b>Number: </b> <?php echo e($anonymous->number); ?><br>
<hr>
<b>Point earned by you: </b> <?php echo e($anonymous->point); ?><br>



Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
