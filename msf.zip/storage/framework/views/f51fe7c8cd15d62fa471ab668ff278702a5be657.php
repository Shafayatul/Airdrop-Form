    <section>
        <!-- Left Sidebar -->
        <aside id="leftsidebar" class="sidebar">
            <!-- User Info -->
            <div class="user-info">
                <div class="image">
                    
                    <?php if($current_user->avatar == null): ?>
                        <img src="<?php echo e(URL::asset('images/user.png')); ?>" width="48" height="48" alt="User" />
                    <?php else: ?>
                        <img src="<?php echo e($current_user->avatar); ?>" width="48" height="48" alt="User" />
                    <?php endif; ?>
                </div>
                <div class="info-container">
                    <div class="name" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><?php echo e($current_user->name); ?></div>
                    <div class="email"><?php echo e($current_user->email); ?></div>
                    <div class="btn-group user-helper-dropdown">
                        <i class="material-icons" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">keyboard_arrow_down</i>
                        <ul class="dropdown-menu pull-right">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Manage Own Profile')): ?>
                            <li>
                                <a href="<?php echo e(url('/profile')); ?>"><i class="material-icons">person</i>Profile</a>
                            </li>
                            <?php endif; ?>
                            <li>
                                <a href="<?php echo e(url('/select-type')); ?>" ><i class="material-icons">autorenew</i>Change Type</a>
                            </li>
                            <li>
                                <a href="<?php echo e(url('/logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();" ><i class="material-icons">input</i>Sign Out</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <form id="logout-form" action="<?php echo e(url('/logout')); ?>" method="POST" style="display: none;">
                <?php echo e(csrf_field()); ?>

            </form>
            <!-- #User Info -->
            <!-- Menu -->
            <div class="menu">
                <ul class="list">
                    <li class="header">MAIN NAVIGATION</li>
                    <li class="active">
                        <a href="<?php echo url('/home'); ?>">
                            <i class="material-icons">dashboard</i>
                            <span>Dashboard</span>
                        </a>
                    </li>
                
                    <li>
                        <a href="<?php echo e(url('/zeros/create')); ?>">
                            <i class="material-icons">spellcheck</i>
                            <span>Step 0 - Ethereum Address</span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(url('/ones/create')); ?>">
                            <i class="material-icons">account_box</i>
                            <span>Step 1 - Address verification</span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(url('/twos/create')); ?>">
                            <i class="material-icons">assessment</i>
                            <span>Step 2 - Medium Level</span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(url('/threes/create')); ?>">
                            <i class="material-icons">perm_phone_msg</i>
                            <span>Step 3 - Phone varification</span>
                        </a>
                    </li>
                    <?php if($current_user->type=="advance"): ?>   
                        <li>
                            <a href="<?php echo e(url('/fours/create')); ?>">
                                <i class="material-icons">school</i>
                                <span>Step 3 - University varification</span>
                            </a>
                        </li>

                        <li>
                            <a href="<?php echo e(url('/fives/create')); ?>">
                                <i class="material-icons">camera_roll</i>
                                <span>Step 4 - Selfi varification</span>
                            </a>
                        </li>
                    <?php endif; ?>

                    
                </ul>
            </div>
        </aside>
        <!-- #END# Left Sidebar -->
        <!-- Right Sidebar -->

        <!-- #END# Right Sidebar -->
    </section>