<?php $__env->startComponent('mail::message'); ?>
# Hello,

Some info here
<br>
<br>
<br>

<b>Privacy: </b> <?php echo e($two->privacy); ?><br>
<hr>
<b>Type: </b> <?php echo e($two->type); ?><br>
<hr>
<b>Number: </b> <?php echo e($two->number); ?><br>
<hr>
<b>Point earned by you: </b> <?php echo e($two->point); ?><br>



Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>