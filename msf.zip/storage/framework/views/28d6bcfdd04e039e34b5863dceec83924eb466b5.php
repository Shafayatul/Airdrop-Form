<div class="row">
	<div class="col-sm-4 col-sm-offset-4 form-design">
		<?php echo Form::label('name', 'Name', ['class' => 'control-label']); ?>

		<?php echo Form::text('name', null, ['class' => 'form-control', 'required' => 'required']); ?>

		<?php echo Form::label('address', 'Address', ['class' => 'control-label']); ?>

		<?php echo Form::text('address', null, ['class' => 'form-control', 'required' => 'required']); ?>


		<br>
		<?php echo NoCaptcha::renderJs(); ?>

		<?php echo NoCaptcha::display(); ?>

		<br>
		<p><input id="field_terms" type="checkbox" required>
		<label for="field_terms">I accept the <u>Terms and Conditions</u></label></p>

		<?php echo Form::submit(isset($submitButtonText) ? $submitButtonText : 'Create', ['class' => 'btn btn-primary btn-block form-margin']); ?>	
	</div>
</div>
