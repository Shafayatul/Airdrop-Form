<?php $__env->startSection('content'); ?>
    <section class="content">
        <div class="container-fluid">
            <div class="block-header">
                <h2>Dashboard</h2>
            </div>
            <!-- Input -->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2>
                                Welcome
                            </h2>
                        </div>
                        <div class="body">

                            <div class="row">

                                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 col-xs-offset-0 col-sm-offset-0 col-md-offset-3 col-lg-offset-3 toppad" >
   
   
                                  <div class="panel panel-info">
                                    <div class="panel-heading">
                                      <h3 class="panel-title">Profile Info</h3>
                                    </div>
                                    <div class="panel-body">
                                      <div class="row">
                                        <div class="col-md-3 col-lg-3 " align="center"> 
                                            <?php if($current_user->avatar == null): ?>
                                                <img alt="User Pic" src="<?php echo e(URL::asset('images/user.png')); ?>" class="img-circle img-responsive"> 
                                            <?php else: ?>
                                                <img alt="User Pic" src="<?php echo e($current_user->avatar); ?>" class="img-circle img-responsive"> 
                                            <?php endif; ?>
                                        </div>


                                        

                                        <div class=" col-md-9 col-lg-9 "> 
                                          <table class="table table-user-information">
                                            <tbody>
                                              <tr>
                                                <td>Name:</td>
                                                <td><?php echo e($current_user->name); ?></td>
                                              </tr>
                                              <tr>
                                                <td>Email</td>
                                                <td><a href="mailto:info@support.com"><?php echo e($current_user->email); ?></a></td>
                                              </tr>
                                              <tr>
                                                <td>Profile Type</td>
                                                <td><?php echo e($current_user->type); ?></td>
                                              </tr>
                                              <tr>
                                                <td>Profile Created At</td>
                                                <td><?php echo e($current_user->created_at); ?></td>
                                              </tr>
                                              <tr>
                                                <td>Point</td>
                                                <td><?php echo e($current_user->point); ?></td>
                                              </tr>
                                            </tbody>
                                          </table>
                                        </div>
                                      </div>
                                    </div>
                                   </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <!-- #END# Input -->
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>