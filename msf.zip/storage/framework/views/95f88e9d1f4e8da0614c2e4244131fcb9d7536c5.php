<?php $__env->startComponent('mail::message'); ?>
# Hello,

Thanks for registering in our Laravel App. You can login any time using your gmail account. To update and see information please visit: <?php echo e(url('/')); ?>

<br>

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
