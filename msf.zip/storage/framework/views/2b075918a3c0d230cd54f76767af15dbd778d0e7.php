<?php $__env->startSection('content'); ?>
    <section class="content">
        <div class="container-fluid">
            <div class="block-header">
                <h2>Selfi Varification</h2>
            </div>
            <!-- Input -->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <div class="row">
                                <div class="col-sm-6">
                                    <h2>
                                        You can also submit this video by Snapchat
                                    </h2>
                                </div>
                                <div class="col-sm-6 text-right">
                                    <a href="<?php echo e(url('/fives/' . $five->id . '/edit')); ?>" title="Edit Zero">
                                        <button class="btn btn-primary btn-sm">
                                            <i class="material-icons">border_color</i> Edit
                                        </button>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="body">
                            
                            <?php if(Session::has('flash_message')): ?>
                                <div class="alert alert-success">
                                    <strong>Success!</strong> <?php echo e(Session::get('flash_message')); ?>

                                </div>
                            <?php endif; ?>

                            <?php if(Session::has('error')): ?>
                            <div class="alert alert-danger">
                                <strong>Error!</strong> <?php echo e(Session::get('error')); ?>

                            </div>
                            <?php endif; ?>   

                            <?php if($errors->any()): ?>
                                <ul class="alert alert-danger">
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            <?php endif; ?>


                            <div class="table-responsive">
                                <table class="table table-borderless">
                                    <tbody>
                  

                                        <tr>
                                            <th> Video </th>
                                            <td> 
                                                <?php if($five->video !=""): ?>
                                                <a href="<?php echo e($five->video); ?>" download="download" target="_blank">Download</a>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th>Referral emails</th><td><?php echo e($five->referral_emails); ?></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
            <!-- #END# Input -->
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>